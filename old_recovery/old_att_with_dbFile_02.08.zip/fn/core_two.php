<?php 

// === FEATCH ATTENDANCE TABLES DATA =====//
$date = strtotime(date('Y-m-d'));
$query = "SELECT * FROM `attendance` WHERE `date` = $date";
$result = mysqli_query($db, $query);
while ($rows = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
	$localData[] = $rows;
}
//pd($localData);

// === FEATCH TEACHERS TABLES DATA =====//
$query1 = "SELECT * FROM `teachers`";
$result1 = mysqli_query($db, $query1);
while ($rows1 = mysqli_fetch_array($result1,MYSQLI_ASSOC)) {
	$localData1[] = $rows1;
}

if(!empty($localData)){
	$teacher_pin = array_column($localData, 'pin');	
}else{
	$teacher_pin = array();
}

//pd($localData1);

 ?>