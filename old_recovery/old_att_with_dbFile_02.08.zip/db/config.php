<?php

// =========== TIME AND SESSION SET ================ //

date_default_timezone_set('asia/dhaka');
session_start();

// =========== DATABASE CONNECTION ================ //
class database{
	public function db()
	{
		$db = new mysqli('localhost', 'root', '', 'attstore');
		if($db->connect_errno > 0){
		    die('Unable to connect to database [' . $db->connect_error . ']');
		}	
		return $db;	
	}	
}

$db = database::db();


// =========== TAD REQUIRE FILE ================ //

require 'lib/TADFactory.php';
require 'lib/TAD.php';
require 'lib/TADResponse.php';
require 'lib/Providers/TADSoap.php';
require 'lib/Providers/TADZKLib.php';
require 'lib/Exceptions/ConnectionError.php';
require 'lib/Exceptions/FilterArgumentError.php';
require 'lib/Exceptions/UnrecognizedArgument.php';
require 'lib/Exceptions/UnrecognizedCommand.php';


// =========== CHECK SESSION FOR SERVER UPLOAD ================ //

if(isset($_SESSION['initialize'])) {
	if(time() - $_SESSION['initialize'] > 1800) {
    	session_destroy();
	}	
}

// ===== CUSTOM FUNCTIONS ===== //

function selected($val1, $val2)
{
	if($val1==$val2){
		$result = "selected='selected'";
	}else{
		$result = '';
	}
	return $result;
}

function workingDaysTotal($date, $month)
{
	$db = database::db();
	$date = strtotime(date("Y-$month-$date"));
	$query = $db->query("SELECT * FROM `attendance` WHERE `date` = $date");
    if($query->num_rows > 1){
    	return true;
    }else{
    	return false;
    }
}

function monthlyReportQueryOne($pin, $month)
{
	$db = database::db();
	$eachPin = $pin;
    $first_day = strtotime(date("Y-$month-01"));
    $last_day = strtotime(date("Y-$month-t"));

    $query = "SELECT * FROM `attendance` WHERE `pin` = $eachPin AND `date` BETWEEN $first_day AND $last_day";
    $result = mysqli_query($db, $query);
    while ($rows = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
      $localData[] = $rows;
    }

    if(!empty($localData)){
      foreach($localData as $eachLocal){
        $localDate[] = date('d', $eachLocal['date']);
      }
    }else{
      $localDate = array();
    }
    return $localDate;
}

function hour_count($timeOne, $timeTwo)
{
	$d1= new DateTime($timeOne); 
	$d2= new DateTime($timeTwo);
	$interval= $d1->diff($d2);
	$value = $interval->h.':'.$interval->i.' Minutes';
	return $value;
}

function pd($data)
{	
	echo '<pre>';
	print_r($data);
	echo '</pre>';
	die();
}