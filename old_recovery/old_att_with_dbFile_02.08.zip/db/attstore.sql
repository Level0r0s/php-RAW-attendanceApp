-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2017 at 10:33 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
`id` int(11) NOT NULL,
  `pin` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  `intime` int(11) NOT NULL,
  `outtime` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `pin`, `name`, `date`, `intime`, `outtime`, `status`) VALUES
(1, 47, '', 1493143200, 1493197911, 1493197920, 2),
(2, 40, '', 1493143200, 1493198002, 1493198023, 2),
(3, 1, '', 1493229600, 1493255346, 0, 1),
(4, 40, '', 1493229600, 1493257289, 0, 1),
(5, 48, '', 1493229600, 1493271140, 1493275818, 2),
(6, 1, '', 1493402400, 1493427916, 1493442537, 2),
(7, 40, '', 1493402400, 1493430038, 0, 1),
(8, 1, '', 1493488800, 1493515061, 0, 1),
(9, 40, '', 1493488800, 1493517059, 0, 1),
(10, 1, '', 1493834400, 1493868090, 0, 1),
(11, 1, '', 1493920800, 1493945980, 0, 1),
(12, 1, '', 1494093600, 1494126927, 0, 1),
(13, 40, '', 1494093600, 1494134415, 1494142591, 2),
(14, 48, '', 1494093600, 1494142583, 1494144713, 2),
(15, 1, '', 1494180000, 1494213016, 0, 1),
(16, 40, '', 1494180000, 1494213045, 0, 1),
(17, 48, '', 1494180000, 1494226194, 0, 1),
(18, 1, '', 1494698400, 1494722598, 0, 1),
(19, 1, '', 1494784800, 1494813641, 0, 1),
(20, 48, '', 1494784800, 1494829881, 1494831691, 2),
(21, 40, '', 1494784800, 1494829888, 0, 1),
(22, 47, '', 1494784800, 1494831719, 1494833521, 2),
(23, 40, '', 1494871200, 1494901151, 0, 1),
(24, 48, '', 1494871200, 1494925181, 0, 1),
(25, 1, '', 1494957600, 1494985185, 0, 1),
(26, 1, '', 1495562400, 1495589546, 0, 1),
(27, 1, '', 1496167200, 1496195235, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
`id` int(11) NOT NULL,
  `pin` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `pin`, `name`) VALUES
(1, 1, 'Md. Fazlur Rahman'),
(2, 2, 'Md. Zakir Hossain'),
(3, 3, 'Sabikun Nahar'),
(4, 4, 'Rasheda Khatun'),
(5, 5, 'Kaniz Fatema'),
(6, 6, 'Abdul Kuddus'),
(7, 7, 'Abdul Aziz'),
(8, 8, 'Abu Sayed Shikder'),
(9, 9, 'Dalim Hossain'),
(10, 10, 'Khadiza Parvin'),
(11, 11, 'Onaiza Begum'),
(12, 12, 'Runa Laila Moni'),
(13, 13, 'Md. Shah Jalal'),
(14, 14, 'Asma Akter'),
(15, 15, 'Md. Shahinur Islam'),
(16, 16, 'Md. Abdul Hai'),
(17, 17, 'Airin Akter'),
(18, 18, 'Rifat Hasan'),
(19, 19, 'Hasina Momtaz'),
(20, 20, 'Sadia Afrin'),
(21, 21, 'Dilruba Nargis'),
(22, 22, 'Shipra'),
(23, 23, 'Roushonara Akter'),
(24, 24, 'Ahalullah'),
(25, 25, 'Malbika Somoddar'),
(26, 26, 'Farhana Chowdhury'),
(27, 27, 'Joy Bepari'),
(28, 28, 'Monira Siddika'),
(29, 29, 'Md. Solaiman Kabir'),
(30, 30, 'Tofayel Hossain'),
(31, 31, 'Md. Zahidul Islam'),
(32, 32, 'Kamrun Nahar'),
(33, 33, 'Tahmina Akter'),
(34, 34, 'Khadiza Rahman Niru'),
(35, 35, 'Ratna Akter'),
(36, 36, 'Abu Taher Tuhin'),
(37, 37, 'Farhana Chowdhury Linda'),
(38, 38, 'Subroto Kumar Das'),
(39, 39, 'Kamrun Nahar Shammi'),
(42, 42, 'Hannan Mia'),
(43, 43, 'Golap Rahman'),
(44, 44, 'Rahima Begum'),
(45, 45, 'Rajia Begum'),
(46, 46, 'Beli Rani'),
(47, 47, 'Soijuddin Sharif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
 ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
